<?php
 
require("RClass.php");

//Instancia de clase; 
$rObject = new R();
$rObject -> executeRCode($r_code);


?>
