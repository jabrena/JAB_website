﻿/*
 * Creado por SharpDevelop.
 * Usuario: JAB
 * Fecha: 11/10/2006
 * Hora: 18:25
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using bren.robotics;

namespace ECT4
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm
	{
		private bren.robotics.ECT ectObject;
		
		[STAThread]
		public static void Main(string[] args)
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new MainForm());
		}
		
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		protected override void OnLoad(EventArgs e) {
			base.OnLoad(e);

			this.ectObject = new ECT();

		}

		void Button1Click(object sender, System.EventArgs e)
		{
			if(this.textBox1.Text == ""){
				MessageBox.Show("Write COMport to connect with NXT brick");
				this.textBox1.Focus();
			}else{
				this.ectObject.SetNXT_COM_PORT(this.textBox1.Text);
				//this.textBox3.Text = "Connecting with ECT...";
				this.ectObject.run();
				if(this.ectObject.GetNXTBrickConnected() == true){
					this.textBox3.Text = "Connected";
				}else{
					this.textBox3.Text = "Error: There was a problem";
				}
			}
		}
		
		
		
		void Button2Click(object sender, System.EventArgs e)
		{
			this.ectObject.getSonarMeasure();
		}
	}
}
