﻿/*
 * Creado por SharpDevelop.
 * Usuario: JAB
 * Fecha: 06/10/2006
 * Hora: 23:54
 * 
 */

using System.Collections.Generic;
using System.ComponentModel;
//using System.Data;
//using System.Drawing;
using System.Text;
using System.Threading;
using System.Windows.Forms;

using System;
using Bram.Lego;
using Bram.Utilities;

namespace bren.robotics
{
	/// <summary>
	/// This class in c# models a ECT, Esmeta Control Tower.
	/// this bot has 2 nxt motors and an a ultrasonic sensor.
	/// </summary>
	public class ECT
	{

		//NXT phisical objects.
		private NxtBrick nxtBrick1;
		private NxtMotor nxtMotorA;//Gyroscope Motor
		private NxtMotor nxtMotorC;//SAZLR Motor
		private NxtSonar nxtSonar4;//Eyes (For Version ECT1)
			
		/// <summary>
		/// Set / Get methods about COM_PORT
		/// </summary>
        private string NXT_COM_PORT;
       	public void SetNXT_COM_PORT(string COM_PORT){
       		this.NXT_COM_PORT = COM_PORT;
        }
      	public string GetNXT_COM_PORT(string COM_PORT){
       		return this.NXT_COM_PORT;
        }

       	//Logic Object
       	private string ULTRASONIC_MEASURE;
       	
       	private bool NXTBrickConnected = false;
      	public bool GetNXTBrickConnected(){
       		return this.NXTBrickConnected;
        }
       	
       	
		public void run()
        {
       	
			//Brick Class definition
			this.nxtBrick1 = new NxtBrick();
            this.nxtBrick1.AutoPoll = true;
            this.nxtBrick1.COMPortName = this.NXT_COM_PORT;
            this.nxtBrick1.MotorA = nxtMotorA;
            this.nxtBrick1.MotorB = null;
            this.nxtBrick1.MotorC = nxtMotorC;
            this.nxtBrick1.Sensor1 = null;
            this.nxtBrick1.Sensor2 = null;
            this.nxtBrick1.Sensor3 = null;
            this.nxtBrick1.Sensor4 = nxtSonar4;
            
            this.nxtMotorA = new NxtMotor();
            this.nxtMotorA.Brick = this.nxtBrick1;
            this.nxtMotorA.Flip = false;
            this.nxtMotorA.Port = Bram.Lego.NxtMotorPort.PortA;
            
            this.nxtMotorC = new NxtMotor();
            this.nxtMotorC.Brick = this.nxtBrick1;
            this.nxtMotorC.Flip = false;
            this.nxtMotorC.Port = Bram.Lego.NxtMotorPort.PortC;
            
            this.nxtSonar4 = new NxtSonar();
            this.nxtSonar4.Brick = this.nxtBrick1;
            this.nxtSonar4.AutoPoll = false;

			//this.nxtSonar4.AutoPollDelay = 0;
            this.nxtSonar4.Port = Bram.Lego.NxtSensorPort.Port4;
            this.nxtSonar4.ValueChanged += new Bram.Lego.SensorEvent(this.nxtSonar4_ValueChanged);
            
 
 			try{
 				this.nxtBrick1.Connect();
				this.NXTBrickConnected = true;
            // Statement which can cause an exception.
            }catch(System.IO.IOException){
            	//MessageBox.Show("Exception occured");
 				this.NXTBrickConnected = false;
            }finally{}
        }
		
		public void turnleft(){
		    int motorForce = -10;
            int rotation =20;//(degrees);           
            this.nxtMotorC.Turn(motorForce, rotation);	
            //this.nxtMotorC.Brake();
		}

		public void turnright(){
		    int motorForce = 10;
            int rotation =20;//(degrees);           
            
            this.nxtMotorC.Turn(motorForce, rotation);
            //this.nxtMotorC.Brake();
		}
		
		public void getSonarMeasure(){
			this.nxtSonar4.Poll();
			MessageBox.Show(this.nxtSonar4.LastPollTimestamp.ToString());
			MessageBox.Show(this.ULTRASONIC_MEASURE);
			MessageBox.Show(this.nxtSonar4.LastResult.ScaledValue.ToString());
			MessageBox.Show(this.nxtSonar4.RawValue.ToString());
			MessageBox.Show(this.nxtSonar4.LastResult.CalibratedValue.ToString());
			MessageBox.Show(this.nxtSonar4.LastResult.Calibrated.ToString());
			MessageBox.Show(this.nxtSonar4.LastResult.Mode.ToString());
			MessageBox.Show(this.nxtSonar4.LastResult.RawAD.ToString());
			MessageBox.Show(this.nxtSonar4.LastResult.Valid.ToString());
		}
		
		private void nxtSonar4_ValueChanged(NxtSensor sensor) {
			this.ULTRASONIC_MEASURE = nxtSonar4.LastResult.ScaledValue.ToString();
		}
		
		public void disconnectECT(){
			this.nxtBrick1.Disconnect();
		}
		
		/// <summary>
		/// This method allow to shoot a Sphere with SAZLR System
		/// </summary>
		public void shoot(){
		    int motorForce = 100;
            int rotation =360;//(degrees);           
            
            this.nxtMotorA.Turn(motorForce, rotation);
		}
	}
}
